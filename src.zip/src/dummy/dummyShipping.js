const dummyShipping = {
  "statusCode": "200",
  "message": "OK",
  "data": [
    {
      "id": "3knk2noib2oi2o23r",
      "via": "udara",
      "estimation": "via udara 10 - 12 hari",
      "price": 20000
    },
    {
      "id": "3knk2noib2oi2o23r",
      "via": "laut",
      "estimation": "via laut 20 - 30 hari",
      "price": 0
    }
  ]
}

export default dummyShipping;